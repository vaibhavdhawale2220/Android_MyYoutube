package com.example.myyoutube;

public class YoutubeConfigApi {
    private static final String API_KEY = "AIzaSyDsoNkFFTVwsrGx-KVawaNYVpLjf2vKWs4";

    public static String getApiKey() {
        return API_KEY;

    }
}


